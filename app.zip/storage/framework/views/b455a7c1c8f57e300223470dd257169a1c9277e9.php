

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/f3.css'); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo asset('css/cards.css'); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-5 py-4">
                <div class="row mt-3">
                    <div class="card  mb-4" style="border:none; padding-bottom: 25px !important; width: 100%">
                        <div class="row">
                            <div class="col-xl-12">
                                <h3 class="mb-4">Filtrar</h3>
                                <br>
                                <form id="filtroForm" action="<?php echo e(url('/inventario/historialMovimientos/filtro')); ?>"
                                    method="GET">
                                    <div class="row mt-1" style="justify-content: center;">
                                        <div class="col-xl-3">
                                            <div class="inputContainer">
                                                <select class="inputField" name="tipoMovimiento" id="tipoMovimiento">
                                                    <?php if(isset($tipoMovimiento)): ?>
                                                        <option value="Seleccione"
                                                            <?php if($tipoMovimiento == ''): ?> selected <?php endif; ?>>Seleccione
                                                        </option>
                                                        <option value="Ingreso"
                                                            <?php if($tipoMovimiento == 'Ingreso'): ?> selected <?php endif; ?>>
                                                            Ingreso
                                                        </option>
                                                        <option value="Salida"
                                                            <?php if($tipoMovimiento == 'Salida'): ?> selected <?php endif; ?>>Salida
                                                        </option>
                                                    <?php else: ?>
                                                        <option value="Seleccione" selected>Seleccione
                                                        </option>
                                                        <option value="Ingreso">Ingreso</option>
                                                        <option value="Salida">Salida</option>
                                                    <?php endif; ?>
                                                </select>
                                                <label class="inputFieldLabel" for="nombre">Tipo de movimiento:</label>
                                                <i class="inputFieldIcon fas fa-house"></i>
                                                <?php $__errorArgs = ['tipoMovimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small style="color:red"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-xl-3">
                                            <div class="inputContainer">
                                                <input class="inputField" autocomplete="false" type="date"
                                                    name="fechaInicio" id="fechaInicio"
                                                    value="<?php echo e(isset($fechaInicio) ? $fechaInicio : ''); ?>">
                                                <label class="inputFieldLabel" for="nombre">Fecha de inicio:</label>
                                                <i class="inputFieldIcon fas fa-house"></i>
                                                <?php $__errorArgs = ['fechaInicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small style="color:red"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-xl-3">
                                            <div class="inputContainer">
                                                <input class="inputField" autocomplete="false" type="date"
                                                    name="fechaFin" id="fechaFin"
                                                    value="<?php echo e(isset($fechaFin) ? $fechaFin : ''); ?>">
                                                <label class="inputFieldLabel" for="nombre">Fecha fin:
                                                    <?php echo e(isset($fechaFin) ? $fechaFin : ''); ?></label>
                                                <i class="inputFieldIcon fas fa-house"></i>
                                                <?php $__errorArgs = ['fechaFin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small style="color:red"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-xl-2">
                                            <button type="submit" class="button button-primary btnConfirmar"
                                                style="margin-top:2%;: 45%" data-bs-pp="tooltip" data-bs-placement="top"
                                                title="Buscar">
                                                <i class="svg-icon fas fa-check"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="d-flex flex-row  align-items-center" style="margin-bottom: 15px;">
                                <h3 class="me-auto">Listado de movimientos</h3>

                                <div class="d-flex" style="gap:8px">
                                    <button type="button" class="button button-pri" style="width: 40px;"
                                        data-bs-pp="tooltip" data-bs-placement="top" title="Imprimir"
                                        onclick="window.location.href = '<?php echo e(url('inventario/historialMovimientos/pdf')); ?>'">
                                        <i class="svg-icon fas fa-print"></i>
                                    </button>

                                    <input id="searchInput" class="inputField card" style="width:80%" autocomplete="off"
                                        placeholder="🔍︎ Buscar" type="search">
                                </div>

                            </div>

                            <table>
                                <thead>
                                    <tr class="head">
                                        <th style="width: 15%"></th>
                                        <th>Fecha</th>
                                        <th>Tipo</th>
                                        <th>Recurso</th>
                                        <th>Valor</th>
                                        <th>Donante</th>
                                        <th>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody id="tableBody">

                                    <?php use App\Http\Controllers\AnimalControlador; ?>
                                    <?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="width: 15%">
                                                <img src="<?php echo e(isset($a->animal->imagen) ? asset($a->animal->imagen) : 'https://static.vecteezy.com/system/resources/previews/017/783/245/original/pet-shop-silhouette-logo-template-free-vector.jpg'); ?>"
                                                    alt="user" class="picture" />
                                            </td>
                                            <td><?php echo e(explode(' ', $item->fechaMovimento)[0]); ?> </td>
                                            <td><?php echo e($item->tipoMovimiento); ?></td>
                                            <td><?php echo e($item->recurso->recurso); ?></td>
                                            <td>
                                                <?php echo e($item->valor . ' (' . $item->recurso->unidadmedida->simbolo . ')'); ?>

                                            </td>

                                            <td>
                                                <?php echo e($item->donante->nombres . ' ' . $item->donante->apellidos); ?></td>
                                            </td>
                                            <td>

                                                <button type="button" class="button button-red btnDelete"
                                                    style="width: 45%" data-bs-toggle="modal" data-bs-target="#modaldeBaja"
                                                    data-bs-pp="tooltip" data-bs-placement="top"
                                                    title="Dar de baja del albergue">
                                                    <i class="svg-icon fas fa-house-circle-xmark"></i>
                                                </button>


                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div id="pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animal_care\resources\views/inventario/historialMovimientos/index.blade.php ENDPATH**/ ?>