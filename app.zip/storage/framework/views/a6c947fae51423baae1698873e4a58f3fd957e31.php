<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Animal Care</title>
    <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>">

    <link href="<?php echo e(url('https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css')); ?>" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        crossorigin="anonymous" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet"
        href="<?php echo e(url('https://cdn.jsdelivr.net/npm/sweetalert2@10.3.5/dist/sweetalert2.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo asset('css/styles.css'); ?>" type="text/css">
    <?php echo $__env->yieldContent('styles'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/f1.css'); ?>" type="text/css">

    <link rel="stylesheet" href="<?php echo asset('css/input.css'); ?>" type="text/css">
</head>

<body class="sb-nav-fixed">
    <?php echo $__env->make('dashboard.MenuSuperior', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav">
        <?php echo $__env->make('dashboard.MenuLateral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="<?php echo e(url('https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js')); ?>"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous">
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/chart-area-demo.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chart-bar-demo.js')); ?>"></script>
    <script src="<?php echo e(asset('js/simple-datatables@latest.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>
    <script src="<?php echo e(url('https://cdn.jsdelivr.net/npm/sweetalert2@10.3.5/dist/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/tablas.js')); ?>"></script>
    <?php if(session('alert')): ?>
        <script>
            Toast.fire({
                icon: "<?php echo e(session('alert')['type']); ?>",
                title: "<?php echo e(session('alert')['message']); ?>",
            });
        </script>
        <?php
            session()->forget('alert');
        ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\animal_care\resources\views/layouts/master.blade.php ENDPATH**/ ?>