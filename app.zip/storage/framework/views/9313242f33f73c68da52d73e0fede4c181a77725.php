<!-- Modal para los registros dados de baja-->
<div class="modal fade" id="tabla" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" style="margin-left: auto; margin-right: auto;">Lista de albergues de baja</h5>
            </div>
            <div class="modal-body">
                <table>
                    <thead>
                        <tr class="head">
                            <th style="width: 8%"></th>
                            <th>Código</th>
                            <th style="width:40%">Descripción</th>
                            <th style="width: 25%">Categoría</th>
                            <th style="width: 20%">Unidad de medida</th>
                            <th></th>

                        </tr>
                    </thead>
                    <tbody id="tableBody">

                        <?php $__currentLoopData = $Recursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php if($item->estado == 0): ?> 
                            <tr class="recurso-row" data-recurso="<?php echo e($item); ?>" data-categoria="<?php echo e($item->categoria); ?>">
                                <td style="width: 8%">
                                    <img src="<?php echo e(asset('img/recurso.png')); ?>" alt="recurso item" class="picture" />
                                </td>
                                <td><?php echo e($item->idRecurso); ?></td>
                                <td style="width: 40%"><?php echo e($item->recurso); ?> </td>
                                <td style="width: 20%"><?php echo e($item->categoria->categoria); ?></td>
                                <td style="width: 15%"><?php echo e($item->unidadmedida->unidadMedida); ?></td>

                                <td>
                                    <div
                                        style="display: flex; align-items: flex-end; gap: 5px; justify-content: center">
                                        <a
                                            href="<?php echo e(url('inventario/recursos/' . $item->idRecurso . '/edit')); ?>" type="button"
                                            class="button button-blue btnUpdate" data-id="<?php echo e($item->idRecurso); ?>"
                                            data-bs-pp="tooltip" data-bs-placement="top"
                                            title="Editar">
                                            <i class="svg-icon fas fa-pencil"></i>
                                        </a>

                                        <button type="button" id="btnDelete" class="button button-red btnDelete"
                                            data-bs-toggle="modal" data-bs-target="#exampleModalToggle"
                                            data-recurso="<?php echo e($item); ?>" data-bs-pp="tooltip"
                                            data-bs-placement="top" title="Eliminar">
                                            <i class="svg-icon fas fa-trash"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal para dar de baja un elemento de la lista-->
<div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-center">
            <div class="modal-header">
                <h5 style="margin-left: auto; margin-right: auto;">¿Desea dar de baja este registro?</h5>
            </div>
            <div class="modal-body text-center">
                <!-- Utiliza la clase text-center para centrar los elementos -->
                <p> <img src="<?php echo e(asset('img/recurso.png')); ?>" alt="user" class="picture"
                        style="width: 35%; height: auto; margin-left: auto; margin-right: auto;"> </p>
                <p>Código: <span id="Codigo"></span></p>
                <p>Descripcion: <span id="Nombre"></span></p>
                <p>Categoría: <span id="Categoria"></span>

            </div>
            <div class="modal-footer text-center" style="margin-left: auto; margin-right: auto;">
                <button id="confirmar" type="submit" class="button button-pri" style="margin-right: 40px">
                    <i class="svg-icon fas fa-check"></i>
                    <span class="lable">Dar de baja</span></button>
                <button type="button" class="button button-red" data-bs-dismiss="modal"> <i
                        class="svg-icon fas fa-xmark"></i>
                    <span class="lable">Cancelar</span> </button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para ver detalles de elementos de la lista-->
<div class="modal fade" id="modalDetalle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-center">
            <div class="modal-header">
                <h5 style="margin-left: auto; margin-right: auto;">Detalles del registro</h5>
            </div>
            <div class="modal-body text-center">
                <!-- Utiliza la clase text-center para centrar los elementos -->
                <p> <img src="<?php echo e(asset('img/recurso.png')); ?>" alt="user" class="picture"
                        style="width: 35%; height: auto; margin-left: auto; margin-right: auto;"> </p>
                <p>Código: <span id="CodigoD"></span></p>
                <p>Descripcion: <span id="NombreD"></span></p>
                <p>Categoría: <span id="CategoriaD"></span>
            </div>
        </div>
    </div>
</div>

<!-- Modal de ayuda -->
<div class="modal fade" id="ayudaRecursos" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-center">
            <div class="modal-header">
                <h3 style="margin-left: auto; margin-right: auto;">Ayuda</h5>
            </div>
            <div class="modal-body text-center">
                <!-- Utiliza la clase text-center para centrar los elementos -->
               
                <p> °En Recursos registramos  los recursos detalladamente tomando en cuenta gestiones de categoria y unidades de medidas.</p>
                <img src="/img/cte1.png" alt="Descripción de la imagen" class="img-fluid">
                <p></p>
                <p>°Cuando se seleccionaa editar el modulo cambia a modificar.</p>
                <img src="/img/cte.png" alt="Descripción de la imagen" class="img-fluid">
                <p></p>
                <p>°Para poder guardar un registro nuevo no deben haber campos vacios.</p>
                
                
            </div>
            <div class="modal-footer text-center" style="margin-left: auto; margin-right: auto;">

                <button type="button" class="button button-red" data-bs-dismiss="modal"> <i
                        class="svg-icon fas fa-xmark"></i>
                    <span class="lable">cerrar</span> </button>
            </div>
        </div>
    </div>
    
</div><?php /**PATH C:\xampp\htdocs\animal_care\resources\views/inventario/recurso/modalesRecurso.blade.php ENDPATH**/ ?>