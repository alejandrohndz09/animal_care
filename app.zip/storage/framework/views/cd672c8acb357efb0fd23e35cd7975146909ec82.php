<!-- Modal para agregar o modificar vacunas al historial de vacunas-->
<div class="modal fade" id="newHistorial" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-center">
            <div class="modal-header">
                <h5 style="margin-left: 35%"> <?php echo e(isset($HistorialV) ? 'Editar Registro' : 'Nuevo Registro'); ?></h5>
                <button type="button" class="circle-button" style="margin-right: 4%" data-bs-dismiss="modal">
                    <i style="height: 30px;width: 45px;margin-right: 8%"
                        class="svg-icon fas fa-regular fa-circle-xmark"></i></button>
            </div>
            <form
                action="<?php echo e(isset($historialV) ? url('historialV/update/' . $historialV->idHistVacuna) : url('animal/' . $animal->idAnimal . '/historialVacuna')); ?>"
                enctype="multipart/form-data" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(isset($historialV)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <div class="modal-body text-center">
                    <br>
                    <input type="hidden" name="idAnimal" value="<?php echo e($animal->idAnimal); ?>">
                    <input type="hidden" name="idExpediente" value="<?php echo e($idExpediente); ?>">
                    <div class="inputContainer">
                        <select id="vacuna" name="vacuna" class="inputField">
                            <option value=""
                                <?php echo e(old('vacuna') == '' && isset($historialV) == null ? 'selected' : ''); ?>>
                                Seleccione...
                            </option>
                            <?php use App\Models\vacuna; ?>
                            <?php $__currentLoopData = Vacuna::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($v->idVacuna); ?>"
                                    <?php echo e(isset($historialV) ? ($historialV->vacuna->idVacuna == $v->idVacuna ? 'selected' : '') : (old('vacuna') == $v->idVacuna ? 'selected' : '')); ?>>
                                    <?php echo e($v->vacuna); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <label class="inputFieldLabel" for="vacuna">Vacuna*</label>
                        <i class="inputFieldIcon fas fa-syringe"></i>
                        <?php $__errorArgs = ['vacuna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="inputContainer">
                        <input id="fechaAplicacion" name="fechaAplicacion"
                            value="<?php echo e(isset($historialV) ? old('fecha', explode(' ', $historialV->fechaAplicacion)[0]) : old('fechaAplicacion')); ?>"
                            max="<?php echo e(date('Y-m-d')); ?>" class="inputField" autocomplete="false" type="date">
                        <label class="inputFieldLabel" for="fechaAplicacion">Fecha de aplicación*</label>
                        <i class="inputFieldIcon fas fa-calendar"></i>
                        <?php $__errorArgs = ['fechaAplicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="inputContainer">
                        <input id="dosis" name="dosis" class="inputField" placeholder="Cantidad" type="number"
                            value="<?php echo e(isset($historialV) ? old('dosis', $historialV->dosis) : old('dosis')); ?>"
                            autocomplete="off">
                        <label class="inputFieldLabel" for="dosis">Dosis*</label>
                        <i class="inputFieldIcon fas fa-vial-circle-check"></i>
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="modal-footer " style="justify-content: center;">
                    <button type="submit" class="button button-pri">
                        <i class="svg-icon fa-regular fa-floppy-disk"></i>
                        <span class="lable">
                            <?php echo e(isset($historialV) ? 'Modificar' : 'Guardar'); ?>

                        </span>
                    </button>
                    <button type="button" id="btnCancelar" class="button button-red" data-bs-dismiss="modal">
                        <i class="svg-icon fas fa-rotate-right"></i>
                        <span class="lable">Cancelar</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\animal_care\resources\views/animal/historial.blade.php ENDPATH**/ ?>