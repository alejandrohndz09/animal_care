

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/f3.css'); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/validaciones/JsDonante.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 py-4">
                <div style=" width: 100%;display: flex;align-items: center;justify-content: space-between;">
                </div>

                <div class="row mt-3">
                    <div class="col-xl-7">
                        <div
                        style="width:100%; display: flex;  justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <div style=" width:100%;margin: 0; display: flex; gap: 5px; align-items: center; ">
                            <button class="button btn-transparent" style="width: 30px;padding: 15px 5px" type="button"
                                id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"
                                data-bs-pp="tooltip" data-bs-placement="top" title="Volver"
                                onclick="window.location.href='/inventario'">
                                <i class="svg-icon fas fa-chevron-left" style="color: #4c4c4c"></i>
                            </button>
                            <h1>Recursos </h1>
                        </div>
                        <div
                            style=" width:100%;margin: 0; display: flex; gap: 5px; justify-content: end ;align-items: center; ">
                            <input id="searchInput" class="inputField card" style="width: 100%;" autocomplete="off"
                                placeholder="🔍︎ Buscar" type="search">

                            <div class="dropdown">
                                <button class="button btn-transparent" style="width: 30px;padding: 15px 5px"
                                    type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                                    aria-expanded="false" data-bs-pp="tooltip" data-bs-placement="top" title="Opciones">
                                    <i class="svg-icon fas fa-ellipsis-vertical" style="color: #4c4c4c"></i>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                    <li><a class="dropdown-item" data-bs-toggle="modal"data-bs-target="#tabla">
                                            Donantes dados de baja</a></li>
                                </ul>
                            </div>

                        </div>
                    </div>
                        
                        <table id="table">
                            <thead>
                                <tr class="head">
                                    <th style="width: 10%"></th>
                                    <th>Nombres</th>
                                    <th>Apellidos</th>
                                    <th>dui</th>
                                    <th></th>

                                </tr>
                            </thead>
                            <tbody id="tableBody">

                                <?php $__currentLoopData = $donantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->estado == 1): ?>
                                        <tr class="donante-row" data-donante="<?php echo e(json_encode($item)); ?>">
                                            <td style="width: 10%">
                                                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/User-avatar.svg/2048px-User-avatar.svg.png"
                                                    alt="user" class="picture" />
                                            </td>
                                            <td><?php echo e($item->nombres); ?></td>
                                            <td><?php echo e($item->apellidos); ?></td>
                                            <td><?php echo e($item->dui); ?> </td>
                                            <td>
                                                <div
                                                    style="display: flex; align-items: flex-end; gap: 5px; justify-content: center">
                                                    <button
                                                        onclick="window.location.href = '<?php echo e(url('inventario/donantes/' . $item->idDonante . '/edit')); ?>';"
                                                        type="button" class="button button-blue btnUpdate"
                                                        style="width: 45%" data-bs-pp="tooltip" data-bs-placement="top"
                                                        title="Editar">
                                                        <i class="svg-icon fas fa-pencil"></i>
                                                    </button>


                                                    <button type="button" class="button button-red btnDelete"
                                                        data-bs-pp="tooltip" data-bs-toggle="modal"
                                                        data-bs-target="#exampleModalToggle" style="width: 45%"
                                                        data-donante="<?php echo e(json_encode($item)); ?>" data-bs-placement="top"
                                                        title="Dar de baja">
                                                        <i class="svg-icon fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="pagination">

                        </div>
                    </div>
                    <div class="col-xl-5">
                        <div class="card  mb-4" style="border:none; padding-bottom: 25px !important; width: 100%">
                            <h3 style="padding: -5px 0px !important;">
                                <?php echo e(isset($donanteEdit) ? 'Editar Registro' : 'Nuevo registro'); ?>

                            </h3>
                            <form
                                action="<?php echo e(isset($donanteEdit) ? url('/inventario/donantes/update/' . $donanteEdit->idDonante) : ''); ?>"
                                id="miFormulario" name="form" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($donanteEdit)): ?>
                                    <?php echo method_field('PUT'); ?> <!-- Utilizar el método PUT para la actualización -->
                                <?php endif; ?>

                                <!-- Input Nombres -->
                                <div class="row">
                                    <div class="col-xl-6">
                                        <div class="inputContainer">
                                            <input name="nombres" id="nombres" class="inputField" placeholder="Nombres"
                                                type="text" autocomplete="off" oninput="validarTexto(this)"
                                                value="<?php echo e(isset($donanteEdit) ? $donanteEdit->nombres : old('nombres')); ?>">
                                            <label class="inputFieldLabel" for="nombre">Nombres*</label>
                                            <i class="inputFieldIcon fas fa-user"></i>
                                            <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small style="color:red"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <!-- Input Apellidos -->
                                    <div class="col-xl-6">
                                        <div class="inputContainer">
                                            <input name="apellidos" class="inputField" autocomplete="off"
                                                placeholder="Apellidos" type="text" oninput="validarTexto(this)"
                                                value="<?php echo e(isset($donanteEdit) ? $donanteEdit->apellidos : old('apellidos')); ?>">
                                            <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small style="color:red"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <!-- Input DUI -->
                                    <div class="col-xl-12">
                                        <div class="inputContainer ">
                                            <input name="dui" id="dui"
                                                value="<?php echo e(isset($donanteEdit) ? $donanteEdit->dui : old('dui')); ?>"
                                                class="inputField" placeholder="00000000-0" type="text"
                                                autocomplete="off" oninput="validarDui(this)">
                                            <label class="inputFieldLabel" name="texto">DUI:*</label>
                                            <i class="inputFieldIcon fas fa-id-card" id="iconDui" name="logoDui"></i>
                                            <?php $__errorArgs = ['dui'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small style="color:red"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>
                                </div>


                                
                                <?php if(!isset($donanteEdit)): ?>
                                    <input type="hidden" name="con" id="con" value="<?php echo e(old('con', 1)); ?>">
                                    <?php  $con = old('con',1); ?>
                                    <div class="row" id="telefono-container">
                                        <?php for($i = 0; $i < $con; $i++): ?>
                                            <div class="row">
                                                <div class="col-xl-6">
                                                    <div class="inputContainer">
                                                        <input class="inputField telefono" id="tel"
                                                            name="telefonosAd[]" type="text" autocomplete="off"
                                                            oninput="validarInput(this)"
                                                            value="<?php echo e(old('telefonosAd.' . $i, '+503 ')); ?>">
                                                        <label class="inputFieldLabel"
                                                            for="telefono">Teléfono(s):*</label>
                                                        <i class="inputFieldIcon fas fa-phone"></i>
                                                        <small style="color:red" class="error-message"></small>
                                                        <?php $__errorArgs = ['telefonosAd.' . $i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <small style="color:red"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-xl-6">
                                                    <?php if($i == 0): ?>
                                                        <button type="button" class="button button-pri"
                                                            id="add-telefono" data-bs-pp="tooltip"
                                                            data-bs-placement="top" title="Añadir teléfono">
                                                            <i class="svg-icon fas fa-plus"></i>
                                                        </button>
                                                    <?php else: ?>
                                                        <button type="button" data-bs-pp="tooltip"
                                                            data-bs-placement="top" title="Eliminar telefono"
                                                            class=" button button-sec remove-telefono" data-telefono-id=""
                                                            data-telefono-e="">
                                                            <i class="svg-icon fas fa-minus"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endfor; ?>
                                    </div>
                                <?php elseif(isset($donanteEdit)): ?>
                                    <?php
                                        $leght = count($donanteEdit->telefono_donantes);
                                    ?>

                                    <input type="hidden" name="con" id="con"
                                        value="<?php echo e(old('con', $leght)); ?>">
                                    <?php $con = old('con', $leght); ?>

                                    <div class="row" id="telefono-container">
                                        <?php $__currentLoopData = $donanteEdit->telefono_donantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row">
                                                <div class="col-xl-6">
                                                    <div class="inputContainer">
                                                        <input class="inputField telefono" id="tel"
                                                            name="telefonosAd[]" type="text" autocomplete="off"
                                                            oninput="validarInput(this)"
                                                            value="<?php echo e(old('telefonosAd.' . $loop->index, $tel->telefono)); ?>">

                                                        <!-- Agrega un campo oculto para almacenar el ID del teléfono -->
                                                        <input type="hidden" name="telefonoIds[]"
                                                            value="<?php echo e($tel->idTelefono); ?>">

                                                        <label class="inputFieldLabel"
                                                            for="telefono">Teléfono(s):*</label>
                                                        <i class="inputFieldIcon fas fa-phone"></i>
                                                        <small style="color:red" class="error-message"></small>
                                                        <?php $__errorArgs = ['telefonosAd.' . $loop->index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <small style="color:red"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-xl-6">
                                                    <?php if($loop->index == 0): ?>
                                                        <button type="button" class="button button-pri"
                                                            id="add-telefono" data-bs-pp="tooltip"
                                                            data-bs-placement="top" title="Añadir teléfono">
                                                            <i class="svg-icon fas fa-plus"></i>
                                                        </button>
                                                    <?php else: ?>
                                                        <button type="button" data-bs-pp="tooltip"
                                                            data-bs-placement="top" title="Eliminar telefono"
                                                            class=" button button-sec remove-telefono"
                                                            data-remove="remove<?php echo e($loop->index); ?>"
                                                            data-telefono-id="<?php echo e($tel->idTelefono); ?>"
                                                            data-telefono-e="<?php echo e($tel->telefono); ?>">
                                                            <i class="svg-icon fas fa-minus"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                


                                <div class="row">
                                    <p style="margin-top: -25px;">(*)Campos Obligatorios</p>
                                </div>


                                <!-- Botones para la vista -->
                                <div style="display: flex; align-items: flex-end; gap: 10px; justify-content: center">
                                    <button type="submit" class="button button-pri" id="buttonAction">
                                        <i class="svg-icon fa-regular fa-floppy-disk"></i>
                                        <span class="lable">
                                            <?php echo e(isset($donanteEdit) ? 'Modificar' : 'Guardar'); ?>

                                        </span>
                                    </button>
                                    <button onclick="window.location.href = '<?php echo e(url('inventario/donantes')); ?>'"
                                        type="button" id="btnCancelar" class="button button-red">
                                        <i class="svg-icon fas fa-rotate-right"></i>
                                        <span class="lable">Cancelar</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <div class="floating-button" data-toggle="modal" data-target="#ayudaD" data-bs-pp="tooltip" data-bs-placement="top" title="Ayuda">
        <span>?</span>
    </div>
    <?php echo $__env->make('inventario.donante.modalesDonante', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animal_care\resources\views/inventario/donante/index.blade.php ENDPATH**/ ?>