



<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/f3.css'); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/validaciones/JsMiembro1.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 py-4">
                <div class="row mt-3">
                    <div class="col-xl-7">
                        <div
                            style="width:100%; display: flex;  justify-content: space-between; align-items: center; margin-bottom: 15px;">
                            <h1>Miembros </h1>
                            <input id="searchInput" class="inputField card" style="width: 50% " autocomplete="off"
                                placeholder="🔍︎ Buscar" type="search">
                        </div>
                        <table>
                            <thead>
                                <tr class="head">
                                    <th style="width: 10%"></th>
                                    <th>Nombres</th>
                                    <th>Apellidos</th>
                                    <th>Correo</th>
                                    <th></th>

                                </tr>
                            </thead>
                            <tbody id="tableBody">

                                <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->estado == 1): ?>
                                        <tr>
                                            <td style="width: 10%">
                                                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/User-avatar.svg/2048px-User-avatar.svg.png"
                                                    alt="user" class="picture" />
                                            </td>
                                            <td><?php echo e($item->nombres); ?></td>
                                            <td><?php echo e($item->apellidos); ?></td>
                                            <td><?php echo e($item->correo); ?> </td>
                                            <td>
                                                <div
                                                    style="display: flex; align-items: flex-end; gap: 5px; justify-content: center">
                                                    <a id="btnmodificar" href="edit/<?php echo e($item->idMiembro); ?>" type="button"
                                                        class="button button-blue" style="width: 45%"
                                                        data-id="<?php echo e($item->idMiembro); ?>" data-bs-pp="tooltip"
                                                        data-bs-placement="top" title="Editar">
                                                        <i class="svg-icon fas fa-pencil"></i>
                                                    </a>

                                                    <button type="button" class="button button-red" data-bs-pp="tooltip"
                                                        data-bs-toggle="modal" data-bs-target="#exampleModalToggle"
                                                        style="width: 45%" data-id="<?php echo e($item->idMiembro); ?>"
                                                        data-nombre="<?php echo e($item->nombres); ?>"
                                                        data-apellido="<?php echo e($item->apellidos); ?>"
                                                        data-correo="<?php echo e($item->correo); ?>" data-bs-placement="top"
                                                        title="Dar de baja">
                                                        <i class="svg-icon fas fa-trash"></i>
                                                    </button>

                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="pagination">

                        </div>
                    </div>
                    <div class="col-xl-5">
                        <div class="card  mb-4" style="border:none; padding-bottom: 25px !important; width: 100%">
                            <h3 style="padding: -5px 0px !important;">
                                <?php echo e(isset($miembroEdit) ? 'Editar Registro' : 'Nuevo registro'); ?>

                            </h3>
                            <form
                                action="<?php echo e(isset($miembroEdit) ? url('miembro1/update/' . $miembroEdit->idMiembro) : ''); ?>"
                                id="miFormulario" name="form" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($miembroEdit)): ?>
                                    <?php echo method_field('PUT'); ?> <!-- Utilizar el método PUT para la actualización -->
                                <?php endif; ?>

                                <!-- Input DUI -->

                                <div class="inputContainer">
                                    <input name="dui" type="text"
                                        value="<?php echo e(isset($miembroEdit) ? old('dui', $miembroEdit->dui) : old('dui')); ?>"
                                        class="inputField" placeholder="00000000-0" type="text" autocomplete="off"
                                        oninput="validarDui(this)">
                                    <label class="inputFieldLabel" for="dui">DUI</label>
                                    <i class="inputFieldIcon fas fa-id-card"></i>
                                    <?php $__errorArgs = ['dui'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger" style="color:red"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <!-- Input Nombres -->
                                <div class="row">
                                    <div class="col-xl-6">
                                        <div class="inputContainer">
                                            <input name="nombres" id="nombres" class="inputField" placeholder="Nombres"
                                                type="text" autocomplete="off"
                                                value="<?php echo e(isset($miembroEdit) ? old('nombres', $miembroEdit->nombres) : old('nombres')); ?>">
                                            <label class="inputFieldLabel" for="nombre">Nombres</label>
                                            <i class="inputFieldIcon fas fa-user"></i>
                                            <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small style="color:red"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <!-- Input Apellidos -->
                                    <div class="col-xl-6">
                                        <div class="inputContainer">
                                            <input name="apellidos" class="inputField" autocomplete="off"
                                                placeholder="Apellidos" type="text"
                                                value="<?php echo e(isset($miembroEdit) ? old('apellidos', $miembroEdit->apellidos) : old('apellidos')); ?>">
                                            <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small style="color:red"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <!-- Input Correo -->
                                <div class="inputContainer">
                                    <input class="inputField" name="correo" autocomplete="off" placeholder="Correo"
                                        type="email"
                                        value="<?php echo e(isset($miembroEdit) ? old('correo', $miembroEdit->correo) : old('correo')); ?>">
                                    <label class="inputFieldLabel">Correo</label>
                                    <i class="inputFieldIcon fas fa-envelope"></i>
                                    <small style="color:red" class="error-message"></small>
                                    <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <input type="hidden" name="con" id="con" value="1">
                                <div class="row" id="telefono-container">
                                    <div class="col-xl-6">
                                        <div class="inputContainer">
                                            <input class="inputField form-control telefono" value="+503 " id="tel"
                                                name="telefonos[]" type="text" oninput="validarInput(this)">
                                            <label class="inputFieldLabel" for="telefono">Teléfono</label>
                                            <i class="inputFieldIcon fas fa-phone"></i>
                                            <small style="color:red" class="error-message"></small>
                                            <?php $__errorArgs = ['telefonos.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-xl-6">
                                        <button type="button" class="button button-pri" id="add-telefono"
                                            data-bs-pp="tooltip" data-bs-placement="top" title="Añadir teléfono">
                                            <i class="svg-icon fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <!-- Condicional para verificar si esta modificando o agregando telefonos -->
                                
                                <!-- Botones para la vista -->
                                <div style="display: flex; align-items: flex-end; gap: 10px; justify-content: center">
                                    <button type="submit" class="button button-pri">
                                        <i class="svg-icon fa-regular fa-floppy-disk"></i>
                                        <span class="lable">
                                            <?php if(isset($miembroEdit)): ?>
                                                Modificar
                                            <?php else: ?>
                                                Guardar
                                            <?php endif; ?>
                                        </span>
                                    </button>
                                    <button class="button button-red">
                                        <i class="svg-icon fas fa-rotate-right"></i>
                                        <span class="lable">Cancelar</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal para la eliminacion de elementos de la lista-->
            <form action="" id="form-edit" name="form">
                <?php echo csrf_field(); ?>
                <div class="modal fade" id="exampleModalToggle" aria-hidden="true"
                    aria-labelledby="exampleModalToggleLabel" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">

                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalToggleLabel">Desea eliminar este registro?</h5>

                            </div>
                            <div class="modal-body">
                                <!-- Aquí puedes mostrar los detalles del registro utilizando el id -->
                                <p>Nombres: <span id="modalRecordNombre"></span></p>
                                <p>Apellidos: <span id="modalRecordApellido"></span></p>
                                <p>Correo: <span id="modalRecordCorreo"></span></p>
                            </div>
                            <div class="modal-footer">
                                <button id="confirmar" type="button" class="btn btn-primary"> Eliminar</button>
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>
                            </div>
                        </div>
                    </div>
            </form>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animal_care\resources\views/miembro1/index.blade.php ENDPATH**/ ?>