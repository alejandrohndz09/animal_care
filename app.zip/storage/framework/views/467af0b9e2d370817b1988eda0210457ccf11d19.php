

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/f3.css'); ?>" type="text/css">
    <style>
        /* Estilo del panel de menú */
        .menu-panel {
            width: 100%;
            padding: 10px 25px;
            border-radius: 5px;
            color: #6067eb;
        }

        /* Estilo del enlace del panel de menú */
        .menu-link {
            text-decoration: none;
            /* Quitar subrayado del enlace */
            color: inherit;
            /* Heredar color del texto */
        }

        /* Estilo del título y del icono */
        .menu-title {
            display: flex;
            align-items: center;
        }

        .menu-panel:hover {
            background-color: #f0f0f0;
            transform: scale(1.01);
            transition: all 0.3s ease;
        }

        .menu-icon {
            font-size: 14px;
            margin-right: 10px;
        }

        /* Estilo de la línea divisoria interna */
        .menu-divider {
            border: 1px solid #ddd;
            margin: 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/validaciones/JsMovimiento.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 py-4">
                <div class="row mt-3">
                    <div class="col-xl-7">
                        <div
                            style="width:100%; display: flex;  justify-content: space-between; align-items: center; margin-bottom: 15px;">
                            <div style=" width:100%;margin: 0; display: flex; gap: 5px; align-items: center; ">
                                <button class="button btn-transparent" style="width: 30px;padding: 15px 5px" type="button"
                                    id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"
                                    data-bs-pp="tooltip" data-bs-placement="top" title="Volver"
                                    onclick="window.location.href='/inventario'">
                                    <i class="svg-icon fas fa-chevron-left" style="color: #4c4c4c"></i>
                                </button>
                                <h1>Movimientos </h1>
                            </div>
                            <div
                                style=" width:100%;margin: 0; display: flex; gap: 5px; justify-content: end ;align-items: center; ">
                                <input id="searchInput" class="inputField card" style="width: 50%;" autocomplete="off"
                                    placeholder="🔍︎ Buscar" type="search">
                            </div>
                        </div>
                        <table>
                            <thead>
                                <tr class="head">
                                    <th style="width: 8%"></th>
                                    <th style="width:20%">Fecha</th>
                                    <th style="width: 15%">Tipo</th>
                                    <th style="width: 20%">Recurso</th>
                                    <th style="width: 20%">Valor</th>
                                    <th></th>

                                </tr>
                            </thead>
                            <tbody id="tableBody">

                                <?php $__currentLoopData = $Movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="movimiento-row" data-movimiento="<?php echo e($item); ?>"
                                        data-recurso="<?php echo e($item->recurso->recurso); ?>"
                                        data-miembro="<?php echo e($item->miembro->nombres . ' ' . $item->miembro->apellidos); ?>"
                                        data-donante="<?php echo e($item->donante); ?>">
                                        <td style="width: 8%">
                                            <img src="<?php echo e(asset('img/recurso.png')); ?>" alt="movimiento item"
                                                class="picture" />
                                        </td>
                                        <td style="width: 20%"><?php echo e(explode(' ', $item->fechaMovimento)[0]); ?> </td>
                                        <td style="width: 15%"><?php echo e($item->tipoMovimiento); ?></td>
                                        <td style="width: 20%"><?php echo e($item->recurso->recurso); ?></td>
                                        <td style="width: 20%">
                                            <?php echo e($item->valor . ' (' . $item->recurso->unidadmedida->simbolo . ')'); ?></td>

                                        <td>
                                            <div
                                                style="display: flex; align-items: flex-end; gap: 5px; justify-content: center">
                                                <a href="<?php echo e(url('inventario/movimientos/' . $item->idMovimiento . '/edit')); ?>"
                                                    type="button" class="button button-blue btnUpdate"
                                                    data-id="<?php echo e($item->idMovimiento); ?>" data-bs-pp="tooltip"
                                                    data-bs-placement="top" title="Editar">
                                                    <i class="svg-icon fas fa-pencil"></i>
                                                </a>

                                                <button type="button" id="btnDelete" class="button button-red btnDelete"
                                                    data-movimiento="<?php echo e($item); ?>"
                                                    onclick="window.location.href = '<?php echo e(url('/inventario/movimientos/destroy/' . $item->idMovimiento)); ?>'"
                                                    data-bs-pp="tooltip" data-bs-placement="top" title="Eliminar">
                                                    <i class="svg-icon fas fa-trash"></i>
                                                </button>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="pagination">
                        </div>
                    </div>
                    <div class="col-xl-5">
                        <div class="card  mb-4" style="border:none; padding-bottom: 25px !important; width: 100%">
                            <h3 style="padding: -5px 0px !important;">
                                <?php echo e(isset($MovimientoEdit) ? 'Editar Registro' : 'Nuevo Registro'); ?></h3>
                            <form
                                action="<?php echo e(isset($MovimientoEdit) ? url('inventario/movimientos/update/' . $MovimientoEdit->idMovimiento) : ''); ?>"
                                id="miFormulario" name="form" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($MovimientoEdit)): ?>
                                    <?php echo method_field('PUT'); ?> <!-- Utilizar el método PUT para la actualización -->
                                <?php endif; ?>

                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="row">
                                            <div class="col-xl-6">
                                                <?php
                                                    // Obtener la fecha actual
                                                    $fechaActual = new DateTime();

                                                    // Restar 7 días
                                                    $fechaResultado = $fechaActual->sub(new DateInterval('P15D'));

                                                ?>
                                                <div class="inputContainer">
                                                    <input id="fecha" name="fecha"
                                                        value="<?php echo e(isset($MovimientoEdit) ? old('fecha', explode(' ', $MovimientoEdit->fechaMovimento)[0]) : old('fecha')); ?>"
                                                        max="<?php echo e(date('Y-m-d')); ?>"
                                                        min="<?php echo e(!isset($MovimientoEdit) ? $fechaResultado->format('Y-m-d') : ''); ?>"
                                                        class="inputField" autocomplete="false"
                                                        placeholder="Fecha de movimiento" type="date">
                                                    <label class="inputFieldLabel" for="fecha">Fecha de
                                                        operación*</label>
                                                    <i class="inputFieldIcon fas fa-calendar"></i>
                                                    <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="inputContainer">
                                                    <select id="tipoMovimiento" name="tipoMovimiento" class="inputField">
                                                        <option value=""
                                                            <?php echo e(old('tipoMovimiento') == '' && !isset($MovimientoEdit) ? 'selected' : ''); ?>>
                                                            Seleccione...</option>
                                                        <option value="Ingreso"
                                                            <?php if(isset($MovimientoEdit)): ?> <?php if($MovimientoEdit->tipoMovimiento == 'Ingreso'): ?>
                                                        selected <?php endif; ?>
                                                        <?php else: ?> <?php if(old('tipoMovimiento') == 'Ingreso'): ?> selected <?php endif; ?>
                                                            <?php endif; ?>>
                                                            Ingreso</option>
                                                        <option value="Salida"
                                                            <?php if(isset($MovimientoEdit)): ?> <?php if($MovimientoEdit->tipoMovimiento == 'Salida'): ?>
                                                        selected <?php endif; ?>
                                                        <?php else: ?> <?php if(old('tipoMovimiento') == 'Salida'): ?> selected <?php endif; ?>
                                                            <?php endif; ?>>
                                                            Salida</option>
                                                    </select>
                                                    <label class="inputFieldLabel" for="raza">Tipo de
                                                        movimiento*</label>
                                                    <i class="inputFieldIcon fas fa-arrow-right-arrow-left"></i>
                                                    <?php $__errorArgs = ['tipoMovimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <input name="donanteE" id="donanteE" class="inputField" type="hidden"
                                            value="<?php echo e(isset($MovimientoEdit) ? old('donanteE', $MovimientoEdit->idDonante) : (isset($donanteElejido) ? old('donanteE', $donanteElejido->idDonante) : old('donanteE'))); ?>">
                                        <div id="donante-container" class="row">
                                            <?php if((isset($MovimientoEdit) && $MovimientoEdit->tipoMovimiento == 'Ingreso') || old('tipoMovimiento') == 'Ingreso'): ?>
                                                <div class="col-xl-5">
                                                    <div class="inputContainer">
                                                        <label class="inputFieldLabel">¿Es de una
                                                            donación?*</label>
                                                        <i class="inputFieldIcon fas fa-question"></i>
                                                        <div style="padding: 3px 15px">
                                                            <?php if(!isset($MovimientoEdit) && !isset($donanteElegido)): ?>
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio"
                                                                        name="isDonado" id="inlineRadio1" value="Sí"
                                                                        <?php echo e(old('isDonado') == 'Sí' ? 'checked' : ''); ?>>
                                                                    <label class="form-check-label"
                                                                        for="Sí">Sí</label>
                                                                </div>
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio"
                                                                        name="isDonado" id="inlineRadio2" value="No"
                                                                        <?php echo e(old('isDonado') == 'No' ? 'checked' : (old('isDonado') == '' ? 'checked' : '')); ?>>
                                                                    <label class="form-check-label"
                                                                        for="No">No</label>
                                                                </div>
                                                            <?php elseif(isset($MovimientoEdit)): ?>
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio"
                                                                        name="isDonado" id="inlineRadio1" value="Sí"
                                                                        <?php echo e($MovimientoEdit->idDonante != null ? 'checked' : ''); ?>>
                                                                    <label class="form-check-label"
                                                                        for="Sí">Sí</label>
                                                                </div>
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio"
                                                                        name="isDonado" id="inlineRadio2" value="No"
                                                                        <?php echo e($MovimientoEdit->idDonante != null ? '' : 'checked'); ?>>
                                                                    <label class="form-check-label"
                                                                        for="No">No</label>
                                                                </div>
                                                            <?php else: ?>
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio"
                                                                        name="isDonado" id="inlineRadio1" value="Sí"
                                                                        <?php echo e($donanteElegido->idDonante != null ? 'checked' : ''); ?>>
                                                                    <label class="form-check-label"
                                                                        for="Sí">Sí</label>
                                                                </div>
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio"
                                                                        name="isDonado" id="inlineRadio2" value="No"
                                                                        <?php echo e($donanteElegido->idDonante != null ? '' : 'checked'); ?>>
                                                                    <label class="form-check-label"
                                                                        for="No">No</label>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <?php $__errorArgs = ['isDonado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-xl-7">
                                                    <div class="d-flex  align-items-center">
                                                        <?php if(!isset($MovimientoEdit) && !isset($donanteElegido)): ?>
                                                            <button type="button" id="btnDonante"
                                                                class="button button-pri" data-bs-toggle="modal"
                                                                data-bs-target="#buscarDonante"
                                                                style="width: 100%;padding: 7px 7px; justify-items: end;
                                                                <?php if(old('isDonado') == '' || old('isDonado') == 'No'): ?> visibility: hidden; <?php endif; ?>">
                                                                <i
                                                                    class="svg-icon fas fa-<?php echo e(old('nombreDonante') == '' ? 'search' : 'user'); ?>"></i>
                                                                <span id= "DonanteName"
                                                                    class="lable"><?php echo e(old('nombreDonante', 'Seleccionar donante')); ?></span>
                                                            </button>

                                                            <input placeholder="Seleccione" type="hidden"
                                                                value="<?php echo e(old('nombreDonante')); ?>" class="inputField"
                                                                name="nombreDonante">
                                                        <?php elseif(isset($MovimientoEdit)): ?>
                                                            <?php if($MovimientoEdit->idDonante == null): ?>
                                                                <button type="button" id="btnDonante"
                                                                    class="button button-pri" data-bs-toggle="modal"
                                                                    data-bs-target="#buscarDonante"
                                                                    style="width: 100%;padding: 7px 7px; justify-items: end; visibility: hidden;">
                                                                    <i class="svg-icon fas fa-search"></i>
                                                                    <span id="DonanteName" class="lable">Seleccionar
                                                                        donante</span>
                                                                </button>
                                                                <input placeholder="Seleccione" type="hidden"
                                                                    value="" class="inputField" id="nombreDonante"
                                                                    name="nombreDonante">
                                                            <?php else: ?>
                                                                <?php $nombre=$MovimientoEdit->donante->nombres.' '.$MovimientoEdit->donante->apellidos;?>
                                                                <button type="button" id="btnDonante"
                                                                    class="button button-pri" data-bs-toggle="modal"
                                                                    data-bs-target="#buscarDonante"
                                                                    style="width: 100%;padding: 7px 7px; justify-items: end;
                                                                    <?php if($MovimientoEdit->idDonante == null || old('isDonado') == 'No'): ?> visibility: hidden; <?php endif; ?>">
                                                                    <i
                                                                        class="svg-icon fas fa-<?php echo e(old('nombreDonante') == '' ? 'search' : 'user'); ?>"></i>
                                                                    <span id= "DonanteName"
                                                                        class="lable"><?php echo e(old('nombreDonante', $nombre)); ?></span>

                                                                </button>

                                                                <input placeholder="Seleccione" type="hidden"
                                                                    value="<?php echo e(old('nombreDonante', $nombre)); ?>"
                                                                    id="nombreDonante" class="inputField"
                                                                    name="nombreDonante">
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php $nombre=$donanteElegido->nombres.' '.$donanteElegido->apellidos;?>
                                                            <button type="button" id="btnDonante"
                                                                class="button button-sec" data-bs-toggle="modal"
                                                                data-bs-target="#buscarDonante"
                                                                style="width: 100%;padding: 7px 7px; justify-items: end;
                                                                <?php if(old('isDonado') == '' || old('isDonado') == 'No'): ?> visibility: hidden; <?php endif; ?>">
                                                                <i
                                                                    class="svg-icon fas fa-<?php echo e(old('nombreDonante', $nombre) == '' ? 'search' : 'user'); ?>"></i>
                                                                <span id= "DonanteName"
                                                                    class="lable"><?php echo e(old('nombreDonante', 'Buscar donante')); ?></span>
                                                            </button>
                                                            <input type="hidden"
                                                                value="<?php echo e(old('nombreDonante', $nombre)); ?>"
                                                                id="nombreDonante" class="inputField"
                                                                name="nombreDonante">
                                                        <?php endif; ?>

                                                        <?php $__errorArgs = ['donanteE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="row">
                                            <div class="col-xl-7">
                                                <div class="inputContainer">
                                                    <label class="inputFieldLabel" for="">Recurso*</label>
                                                    <i class="inputFieldIcon fas fa-coins"></i>
                                                    <select id="recurso" name="recurso" class="inputField">
                                                        <option value=""
                                                            <?php echo e(old('recurso') == '' && !isset($MovimientoEdit) ? 'selected' : ''); ?>>
                                                            Seleccione...
                                                        </option>
                                                        <?php use App\Models\Recurso; ?>
                                                        <?php $__currentLoopData = Recurso::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recurso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($recurso->idRecurso); ?>"
                                                                <?php echo e(isset($MovimientoEdit) ? ($MovimientoEdit->recurso->idRecurso == $recurso->idRecurso ? 'selected' : '') : (old('recurso') == $recurso->idRecurso ? 'selected' : '')); ?>>
                                                                <?php echo e($recurso->recurso); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['recurso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small style="color:red"><?php echo e($message); ?></small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-xl-5">
                                                <div class="inputContainer">
                                                    <label class="inputFieldLabel" id="valor" autocomplete="off"
                                                        for="valor"
                                                        style="color: #<?php echo e(isset($MovimientoEdit) ? '6067eb' : (old('valor') == '' ? '878787' : '6067eb')); ?>">
                                                        Valor*</label>
                                                    <i class="inputFieldIcon fas fa-cash-register" id="icValor"
                                                        style="color: #<?php echo e(isset($MovimientoEdit) ? '6067eb' : (old('valor') == '' ? '878787' : '6067eb')); ?>"></i>
                                                    <input autocomplete="off"
                                                        value="<?php echo e(isset($MovimientoEdit) ? old('valor', $MovimientoEdit->valor) : old('valor', '1')); ?>"
                                                        <?php echo e(isset($MovimientoEdit) ? '' : (old('valor') == '' ? 'disabled' : '')); ?>

                                                        class="inputField" type="number" min="1" step="1"
                                                        value="1" name="valor">
                                                    <?php $__errorArgs = ['valor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small style="color:red"><?php echo e($message); ?></small>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="inputContainer">
                                            <label class="inputFieldLabel" autocomplete="off"
                                                for="movimiento">Concepto*</label>
                                            <i class="inputFieldIcon fas fa-pencil"></i>
                                            <textarea id="concepto" name="concepto" class="inputField" placeholder="Ej. Gasto en 'x' asunto del mes 'y'."
                                                rows="2" cols="50"><?php echo e(isset($MovimientoEdit) ? old('concepto', $MovimientoEdit->descripcion) : old('concepto')); ?></textarea>
                                            <?php $__errorArgs = ['concepto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small style="color:red"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <p style="margin-top: -25px;">(*)Campos Obligatorios</p>
                                    </div>
                                    <div style="display: flex; align-items: flex-end; gap: 10px; justify-content: center">
                                        <button type="submit" class="button button-pri">
                                            <i class="svg-icon fa-regular fa-floppy-disk"></i>
                                            <span class="lable">
                                                <?php if(isset($MovimientoEdit)): ?>
                                                    Modificar
                                                <?php else: ?>
                                                    Guardar
                                                <?php endif; ?>
                                            </span>
                                        </button>
                                        <button onclick="<?php echo e(url('inventario/movimientos')); ?>" type="button"
                                            id="btnCancelar" class="button button-red">
                                            <i class="svg-icon fas fa-rotate-right"></i>
                                            <span class="lable">Cancelar</span>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <!-- Botón de ayuda -->
    <div class="floating-button" data-toggle="modal" data-target="#ayudaMovimiento" data-bs-pp="tooltip" data-bs-placement="top" title="Ayuda">
        <span>?</span>
    </div>
    <?php echo $__env->make('inventario.movimiento.modalesMovimiento', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animal_care\resources\views/inventario/movimiento/index.blade.php ENDPATH**/ ?>