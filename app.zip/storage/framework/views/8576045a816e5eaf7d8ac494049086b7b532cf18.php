
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/f3.css'); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/validaciones/jsAnimal.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 py-4">
                <div class="row">
                    <div class="col-xl-7">
                        <div
                            style="width:100%; display: flex;  justify-content: space-between; align-items: center; margin-bottom: 15px;">
                            <div style=" width:100%;margin: 0; display: flex; gap: 5px; align-items: center; ">
                                <button class="button btn-transparent" style="width: 30px;padding: 15px 5px" type="button"
                                    data-bs-pp="tooltip" data-bs-placement="top" title="Volver"
                                    onclick="window.location.href='/'">
                                    <i class="svg-icon fas fa-chevron-left" style="color: #4c4c4c"></i>
                                </button>
                                <h1>Animales </h1>
                            </div>
                            <div
                                style=" width:100%;margin: 0; display: flex; gap: 5px; justify-content: end ;align-items: center; ">
                                <input id="searchInput" class="inputField card" style="width: 100%;" autocomplete="off"
                                    placeholder="🔍︎ Buscar" type="search">

                                <div class="dropdown">
                                    <button class="button btn-transparent" style="width: 30px;padding: 15px 5px"
                                        type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                                        aria-expanded="false" data-bs-pp="tooltip" data-bs-placement="top" title="Opciones">
                                        <i class="svg-icon fas fa-ellipsis-vertical" style="color: #4c4c4c"></i>
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                        <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#tabla">Animales de
                                            baja</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                        

                        <table>
                            <thead>
                                <tr class="head">
                                    <th></th>
                                    <th>Código</th>
                                    <th>Nombre</th>
                                    <th>Especie</th>
                                    <th>Raza</th>
                                    <th>Edad</th>
                                    <th>
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="tableBody">

                                <?php use App\Http\Controllers\AnimalControlador; ?>
                                <?php $__currentLoopData = $animales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($a->estado == 1): ?>
                                        <tr class="animal-row" data-animal="<?php echo e(json_encode($a)); ?>">
                                            <td>
                                                <img src="<?php echo e(isset($a->imagen) ? asset($a->imagen) : asset('img/especie.png')); ?>"
                                                    alt="user" class="picture" />
                                            </td>
                                            <td><?php echo e($a->idAnimal); ?></td>
                                            <td><?php echo e($a->nombre); ?></td>
                                            <td><?php echo e($a->raza->especie->especie); ?></td>
                                            <td><?php echo e($a->raza->raza); ?></td>
                                            <td><?php echo e(AnimalControlador::calcularEdad(explode(' ', $a->fechaNacimiento)[0])); ?>

                                            </td>
                                            <td>
                                                <div
                                                    style="display: flex; align-items: flex-end; gap: 3px; justify-content: center">
                                                    <a href="<?php echo e(url('animal/' . $a->idAnimal . '/edit')); ?>"
                                                        class="button button-blue btnUpdate" style="width: 45%;"
                                                        data-bs-pp="tooltip" data-bs-placement="top" title="Editar">
                                                        <i class="svg-icon fas fa-pencil"></i>
                                                    </a>
                                                    <button type="button" class="button button-red btnDelete"
                                                        style="width: 45%" data-bs-toggle="modal"
                                                        data-bs-target="#exampleModalToggle"
                                                        data-animal="<?php echo e(json_encode($a)); ?>" data-bs-pp="tooltip"
                                                        data-bs-placement="top" title="Dar de baja">
                                                        <i class="svg-icon fas fa-trash"></i>
                                                    </button>

                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="pagination"></div>
                    </div>
                    <div class="col-xl-5">
                        <div class="card  mb-4" style="border:none; padding-bottom: 25px !important; width: 100%">
                            <h3 style="padding: -5px 0px !important;">
                                <?php echo e(isset($animal) ? 'Editar Registro' : 'Nuevo Registro'); ?></h3>
                            <form action="<?php echo e(isset($animal) ? url('animal/update/' . $animal->idAnimal) : ''); ?>"
                                method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($animal)): ?>
                                    <?php echo method_field('PUT'); ?>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-xl-4">
                                        <input type="hidden"
                                            value="<?php echo e(isset($animal) ? old('imageTemp', $animal->imagen) : old('imagenTemp')); ?>"
                                            id="imagenTemp" name="imagenTemp">

                                        <label id="image-preview" class="custum-file-upload"
                                            style="margin-top:-10px; width: auto; height: 75%;
                                        <?php echo e(isset($animal)
                                            ? 'background-image: url(' . asset(old('imagenTemp', $animal->imagen)) . ')'
                                            : 'background-image: url(' . old('imagenTemp') . ')'); ?>"
                                            for="foto" data-bs-pp="tooltip" data-bs-placement="left"
                                            title="Subir imagen">
                                            <div class="icon" id="iconContainer" style="color:#c4c4c4;">
                                                <i style="height: 55px; padding: 10px" class="fas fa-camera"></i>
                                            </div>

                                            <input type="file" name="foto" id="foto"
                                                accept="image/jpeg,image/png">
                                        </label>
                                        <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" style="line-height: 0.05px"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-xl-8">
                                        <div class="inputContainer">
                                            <input id="nombre" name="nombre" autocomplete="off" class="inputField" placeholder="Nombre"
                                                type="text"
                                                value="<?php echo e(isset($animal) ? old('nombre', $animal->nombre) : old('nombre')); ?>"
                                                autocomplete="off">
                                            <label class="inputFieldLabel" for="nombre">Nombre*</label>
                                            <i class="inputFieldIcon fas fa-pen"></i>
                                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="inputContainer">
                                            <input id="fecha" name="fecha"
                                                value="<?php echo e(isset($animal) ? old('fecha', explode(' ', $animal->fechaNacimiento)[0]) : old('fecha')); ?>"
                                                max="<?php echo e(date('Y-m-d')); ?>" class="inputField" autocomplete="false"
                                                placeholder="Fecha de nacimiento" type="date">
                                            <label class="inputFieldLabel" for="fecha">Fecha de nacimiento
                                                estimada*</label>
                                            <i class="inputFieldIcon fas fa-calendar"></i>
                                            <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                </div>

                                <div class="inputContainer">
                                    <select id="especie" name="especie" class="inputField">
                                        <option value=""
                                            <?php echo e(old('especie') == '' && isset($animal) == null ? 'selected' : ''); ?>>
                                            Seleccione...
                                        </option>
                                        <?php use App\Models\Especie; ?>
                                        <?php $__currentLoopData = Especie::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($e->idEspecie); ?>"
                                                <?php echo e(isset($animal) ? ($animal->raza->idEspecie == $e->idEspecie ? 'selected' : '') : (old('especie') == $e->idEspecie ? 'selected' : '')); ?>>
                                                <?php echo e($e->especie); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <label class="inputFieldLabel" for="especie">Especie*</label>
                                    <i class="inputFieldIcon fas fa-dog"></i>
                                    <?php $__errorArgs = ['especie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="inputContainer">
                                    <select id="raza" name="raza"
                                        data-selected="<?php echo e(isset($animal) ? $animal->idRaza : old('raza')); ?>"
                                        class="inputField">
                                        <option value="">Seleccione...</option>

                                    </select>
                                    <label class="inputFieldLabel" for="raza">Raza*</label>
                                    <i class="inputFieldIcon fas fa-paw"></i>
                                    <?php $__errorArgs = ['raza'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="inputContainer">
                                    <label class="inputFieldLabel">sexo*</label>
                                    <i class="inputFieldIcon fas fa-question"></i>
                                    <div style="padding: 3px 15px">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="sexo"
                                                id="inlineRadio1" value="Hembra"
                                                <?php echo e((isset($animal) && old('sexo', $animal->sexo) == 'Hembra') || old('sexo') == 'Hembra' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="Hembra">Hembra</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="sexo"
                                                id="inlineRadio2" value="Macho"
                                                <?php echo e(isset($animal) ? (old('sexo', $animal->sexo) == 'Macho' ? 'checked' : '') : (old('sexo') == 'Macho' ? 'checked' : '')); ?>>
                                            <label class="form-check-label" for="Macho">Macho</label>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="inputContainer">
                                    <textarea id="particularidad" name="particularidad" class="inputField"
                                        placeholder="Ej. Mancha en la panza, ojos de diferente color, etc." rows="2" cols="50"><?php echo e(isset($animal) ? old('particularidad', $animal->particularidad) : old('particularidad')); ?></textarea>

                                    <label class="inputFieldLabel" for="particularidad">Alguna Particularidad</label>
                                    <i class="inputFieldIcon fas fa-magnifying-glass-plus"></i>
                                    <?php $__errorArgs = ['particularidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <p style="margin-top: -25px;">(*)Campos Obligatorios</p>

                                <div style="display: flex; align-items: flex-end; gap: 10px; justify-content: center">

                                    <button type="submit" class="button button-pri">
                                        <i class="svg-icon fa-regular fa-floppy-disk"></i>
                                        <span class="lable">
                                            <?php echo e(isset($animal) ? 'Modificar' : 'Guardar'); ?>

                                        </span>
                                    </button>
                                    <button type="button" id="btnCancelar" class="button button-red"
                                        onclick="<?php echo e(url('animal')); ?>">
                                        <i class="svg-icon fas fa-rotate-right"></i>
                                        <span class="lable">Cancelar</span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <?php echo $__env->make('animal.modalesAnimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php if(session()->has('alert')): ?>
        <script>
            Toast.fire({
                icon: "<?php echo e(session()->get('alert')['type']); ?>",
                title: "<?php echo e(session()->get('alert')['message']); ?>",
            });

        <?php
            session()->keep('alert');
        ?>
    </script>
<?php endif; ?>
<div class="floating-button" data-toggle="modal" data-target="#ayudaAnimal" data-bs-pp="tooltip" data-bs-placement="top" title="Ayuda">
    <span>?</span>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animal_care\resources\views/animal/index.blade.php ENDPATH**/ ?>