<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PDF</title>
    
    <style>
        body {
            font-family: Times, "Times New Roman", serif;
            margin: 20px;
            font-size: 14px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        .info-label {
            font-weight: bold;
            margin-bottom: 4px;
        }

        .info-value {
            display: block;
            margin-bottom: 16px;
        }

        hr {
            border: 0;
            height: 1px;
            background: #ccc;
            margin: 20px 0;
        }

        h3 {
            margin-top: 20px;
            text-align: center;
            font-size: 18px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            border-top: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .picture {
            max-width: 100%;
            height: auto;
            display: block;
            margin: 0 auto;
        }
    </style>
</head>
    


<body>
    <div class="container">
        <h1>Detalles del Albergue</h1>
        <hr>

        <div>
            <span class="info-label">Código:</span>
            <span class="info-value"><?php echo e($albergue->idAlvergue); ?></span>
        </div>

        <div>
            <span class="info-label">Dirección:</span>
            <span class="info-value"><?php echo e($albergue->direccion); ?></span>
        </div>
        <div>
            <span class="info-label">Miembro a cargo:</span>
            <span class="info-value"><?php echo e($albergue->miembro->nombres . ' ' . $albergue->miembro->apellidos); ?></span>
        </div>
        <div>
            <span class="info-label">Animales albergados:</span>
            <span class="info-value"><?php echo e(count($albergue->expedientes)); ?></span>
        </div>
        <h3>Animales albergados</h3>
        <table>
            <thead>
                <tr class="head">
                    <th style="width: 15%"></th>
                    <th>Cod. Expediente</th>
                    <th>Nombre</th>
                    <th>Especie</th>
                    <th>Raza</th>
                    <th class="edad-cell">Edad</th>
                </tr>
            </thead>
            <tbody id="tableBody">

                <?php use App\Http\Controllers\AnimalControlador; ?>
                <?php $__currentLoopData = $albergue->expedientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="width: 15%">
                            <?php if(!is_null($a->animal) && !empty($a->animal->imagen)): ?>
                                <img src="<?php echo e($a->animal->imagen); ?>" alt="user" class="picture" />
                            <?php else: ?>
                                <img src="https://static.vecteezy.com/system/resources/previews/017/783/245/original/pet-shop-silhouette-logo-template-free-vector.jpg"
                                    alt="user" class="picture" />
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($a->idExpediente); ?></td>
                        <td><?php echo e($a->animal->nombre); ?></td>
                        <td><?php echo e($a->animal->raza->especie->especie); ?></td>
                        <td><?php echo e($a->animal->raza->raza); ?></td>
                        <td><?php echo e(AnimalControlador::calcularEdad(explode(' ', $a->fechaNacimiento)[0])); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <script type="text/php">
        if ( isset($pdf) ) {
            $font = $fontMetrics->get_font("Arial, Helvetica, sans-serif", "normal");
            $size = 12;
            $pdf->text(270, 820, "Pág $PAGE_NUM de $PAGE_COUNT", $font, 10);
            $fechaActual = now();
            $pdf->text(490, 805, "Fecha: " . $fechaActual->format('d-m-Y'), $font, $size);
            $pdf->text(490, 820, "Hora: " . $fechaActual->format('H:i:s'), $font, $size);
        }
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\animal_care\resources\views/albergue/pdf.blade.php ENDPATH**/ ?>