
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/f3.css'); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/validaciones/jsUnidadMedida.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 py-4">
                <div class="row mt-3">
                    <div class="col-xl-7">
                        <div
                            style="width:100%; display: flex;  justify-content: space-between; align-items: center; margin-bottom: 15px;">
                            <div style=" width:100%;margin: 0; display: flex; gap: 5px; align-items: center; ">
                                <button class="button btn-transparent" style="width: 30px;padding: 15px 5px" type="button"
                                    id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"
                                    data-bs-pp="tooltip" data-bs-placement="top" title="Volver"
                                    onclick="window.location.href='/inventario/recursos'">
                                    <i class="svg-icon fas fa-chevron-left" style="color: #4c4c4c"></i>
                                </button>
                                <h1>Unidades de Medida </h1>
                            </div>
                            <div
                                style=" width:100%;margin: 0; display: flex; gap: 5px; justify-content: end ;align-items: center; ">
                                <input id="searchInput" class="inputField card" style="width: 100%;" autocomplete="off"
                                    placeholder="🔍︎ Buscar" type="search">
                            </div>
                        </div>
                        <table>
                            <thead>
                                <tr class="head">
                                    <th style="width: 10%"></th>
                                    <th style="width: 15%">Código</th>
                                    <th style="width: 20%;">Nombre</th>
                                    <th style="width: 15%;">Símbolo</th>
                                    <th style="width: 20%;">Categoría</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="tableBody">
                                <?php $__currentLoopData = $unidadMedidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="unidadMedida-row" data-unidadMedida="<?php echo e(json_encode($a)); ?>">
                                        <td style="width: 10%">
                                            <img src="<?php echo e(asset('img/unidadMedida.png')); ?>" alt="UnidadMedida" class="picture" />
                                        </td>
                                        <td style="width: 15%"><?php echo e($a->idUnidadMedida); ?></td>
                                        <td style="width: 20%"><?php echo e($a->unidadMedida); ?></td>
                                        <td style="width: 15%;"><?php echo e($a->simbolo); ?></td>
                                        <td style="width: 20%"><?php echo e($a->categoria==null? 'Indistinto': $a->categoria->categoria); ?></td>
                                        <td>
                                            <div
                                                style="display: flex; align-items: flex-end; gap: 3px; justify-content: center">
                                                <a href="<?php echo e(url('/inventario/unidadMedidas/' . $a->idUnidadMedida . '/edit')); ?>"
                                                    class="button button-blue btnUpdate" style="width: 45%;"
                                                    data-bs-pp="tooltip" data-bs-placement="top" title="Editar">
                                                    <i class="svg-icon fas fa-pencil"></i>
                                                </a>
                                                <button type="button" class="button button-red btnDelete"
                                                    style="width: 45%" data-bs-toggle="modal"
                                                    data-bs-target="#exampleModalToggle"
                                                    data-unidadMedida="<?php echo e(json_encode($a)); ?>" data-bs-pp="tooltip"
                                                    data-bs-placement="top" title="Eliminar">
                                                    <i class="svg-icon fas fa-trash"></i>
                                                </button>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="pagination"></div>
                    </div>
                    <div class="col-xl-5">
                        <div class="card  mb-4" style="border:none; padding-bottom: 25px !important; width: 100%">
                            <h3 style="padding: -5px 0px !important;">
                                <?php echo e(isset($unidadMedida) ? 'Editar Registro' : 'Nuevo Registro'); ?></h3>
                            <form
                                action="<?php echo e(isset($unidadMedida) ? url('/inventario/unidadMedidas/update/' . $unidadMedida->idUnidadMedida) : ''); ?>"
                                method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($unidadMedida)): ?>
                                    <?php echo method_field('PUT'); ?>
                                <?php endif; ?>

                                <div class="inputContainer">
                                    <input id="unidadMedida" name="unidadMedida" class="inputField" placeholder="Ej. Kilogramos, libras, unidades, etc..."
                                        type="text"
                                        value="<?php echo e(isset($unidadMedida) ? old('unidadMedida', $unidadMedida->unidadMedida) : old('unidadMedida')); ?>"
                                        autocomplete="off">
                                    <label class="inputFieldLabel" for="unidadMedida">Nombre de la unidad de medida*</label>
                                    <i class="inputFieldIcon fas fa-ruler"></i>
                                    <?php $__errorArgs = ['unidadMedida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="inputContainer">
                                    <input id="unidadMedida" name="simbolo" class="inputField" placeholder="Ej. Kg, lb, uds, etc..."
                                        type="text"
                                        value="<?php echo e(isset($unidadMedida) ? old('simbolo', $unidadMedida->simbolo) : old('simbolo')); ?>"
                                        autocomplete="off">
                                    <label class="inputFieldLabel" for="simbolo">Simbolo*</label>
                                    <i class="inputFieldIcon fas fa-question"></i>
                                    <?php $__errorArgs = ['simbolo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="inputContainer">
                                    <select id="categoria" name="categoria" class="inputField">
                                        <option value=""
                                            <?php echo e(old('categoria') == '' && isset($unidadMedida) == null ? 'selected' : ''); ?>>
                                            Seleccione...
                                        </option>
                                        <option value="-1"
                                            <?php echo e(isset($unidadMedida) ? ($unidadMedida->categoria == null ? 'selected' : '') : (old('categoria') == -1 ? 'selected' : '')); ?>>
                                            Ninguna (Puede usarse en más de una categoría)
                                        </option>
                                        <?php use App\Models\Categoria; ?>
                                        <?php $__currentLoopData = Categoria::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($e->idCategoria); ?>"
                                                <?php echo e(isset($unidadMedida) ? ($unidadMedida->idCategoria == $e->idCategoria ? 'selected' : '') : (old('categoria') == $e->idCategoria ? 'selected' : '')); ?>>
                                                <?php echo e($e->categoria); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <label class="inputFieldLabel" for="categoria">Categoría*</label>
                                    <i class="inputFieldIcon fas fa-tag"></i>
                                    <?php $__errorArgs = ['categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <p style="margin-top: -25px;">(*)Campos Obligatorios</p>

                                <div style="display: flex; align-items: flex-end; gap: 10px; justify-content: center">
                                    <button type="submit" class="button button-pri">
                                        <i class="svg-icon fa-regular fa-floppy-disk"></i>
                                        <span class="lable">
                                            <?php if(isset($unidadMedida)): ?>
                                                Modificar
                                            <?php else: ?>
                                                Guardar
                                            <?php endif; ?>
                                        </span>
                                    </button>
                                    <button type="button" id="btnCancelar" class="button button-red">
                                        <i class="svg-icon fas fa-rotate-right"></i>
                                        <span class="lable">Cancelar</span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <?php echo $__env->make('inventario.unidadMedida.modalesUnidadMedida', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animal_care\resources\views/inventario/unidadMedida/index.blade.php ENDPATH**/ ?>