

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/f3.css'); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/validaciones/JsAlbergue.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 py-4">
                <div class="row mt-3">
                    <div class="col-xl-7">
                        <div
                            style="width:100%; display: flex;  justify-content: space-between; align-items: center; margin-bottom: 15px;">
                            <div style=" width:100%;margin: 0; display: flex; gap: 5px; align-items: center; ">
                                <button class="button btn-transparent" style="width: 30px;padding: 15px 5px" type="button"
                                    id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"
                                    data-bs-pp="tooltip" data-bs-placement="top" title="Volver"
                                    onclick="window.location.href='/'">
                                    <i class="svg-icon fas fa-chevron-left" style="color: #4c4c4c"></i>
                                </button>
                                <h1>Albergues </h1>
                            </div>
                            <input id="searchInput" class="inputField card" style="width: 50%; margin-left: 20% "
                                autocomplete="off" placeholder="🔍︎ Buscar" type="search">

                            <div class="dropdown">
                                <button class="button btn-transparent" style="width: 30px;padding: 15px 5px" type="button"
                                    id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="svg-icon fas fa-ellipsis-vertical" style="color: #4c4c4c"></i>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                    <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#tabla">Albergue de
                                            baja</a></li>
                                </ul>
                            </div>
                        </div>
                        <table>
                            <thead>
                                <tr class="head">
                                    <th style="width: 10%"></th>
                                    <th>Código</th>
                                    <th style="width: 40%">Direccion</th>
                                    <th>Responsable</th>
                                    <th></th>

                                </tr>
                            </thead>
                            <tbody id="tableBody">

                                <?php $__currentLoopData = $Albergues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->estado == 1): ?>
                                        <tr class="registro-row">
                                            <td style="width: 10%">
                                                <img src="<?php echo e(asset('img/albergue.png')); ?>" alt="user" class="picture" />
                                            </td>
                                            <td><?php echo e($item->idAlvergue); ?></td>
                                            <td style="width: 40%"><?php echo e($item->direccion); ?> </td>
                                            <td><?php echo e($item->miembro->nombres); ?> <?php echo e($item->miembro->apellidos); ?></td>

                                            <td>
                                                <div
                                                    style="display: flex; align-items: flex-end; gap: 5px; justify-content: center">
                                                    <a id="btnmodificar"
                                                        href="<?php echo e(url('albergue/' . $item->idAlvergue . '/edit')); ?>"
                                                        type="button" class="button button-blue btnUpdate"
                                                        data-id="<?php echo e($item->idAlvergue); ?>" style="width: 45%"
                                                        data-bs-pp="tooltip" data-bs-placement="top" title="Editar">
                                                        <i class="svg-icon fas fa-pencil"></i>
                                                    </a>

                                                    <button type="button" class="button button-red btnDelete"
                                                        style="width: 45%" data-bs-toggle="modal"
                                                        data-bs-target="#modalDetalle" data-id="<?php echo e($item->idAlvergue); ?>"
                                                        data-nombre="<?php echo e($item->miembro->nombres); ?>"
                                                        data-apellido="<?php echo e($item->miembro->apellidos); ?>"
                                                        data-direccion="<?php echo e($item->direccion); ?>" data-bs-pp="tooltip"
                                                        data-bs-placement="top" title="Dar de baja">
                                                        <i class="svg-icon fas fa-trash"></i>
                                                    </button>

                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="pagination">
                        </div>
                    </div>
                    <div class="col-xl-5">
                        <div class="card  mb-4" style="border:none; padding-bottom: 25px !important; width: 100%">
                            <h3 style="padding: -5px 0px !important;">
                                <?php echo e(isset($AlbergueEdit) ? 'Editar Registro' : 'Nuevo Registro'); ?></h3>
                            <form
                                action="<?php echo e(isset($AlbergueEdit) ? url('albergue/update/' . $AlbergueEdit->idAlvergue) : ''); ?>"
                                id="miFormulario" name="form" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($AlbergueEdit)): ?>
                                    <?php echo method_field('PUT'); ?> <!-- Utilizar el método PUT para la actualización -->
                                <?php endif; ?>

                                <div class="row">
                                    <div class="col-xl-12">

                                        <div class="inputContainer">
                                            <label class="inputFieldLabel" autocomplete="off"
                                                for="direccion">Dirección</label>
                                            <i class="inputFieldIcon fas fa-location-dot"></i>
                                            <input autocomplete="off" placeholder="Ej. Calle Principal #123, Ciudad"
                                                value="<?php echo e(isset($AlbergueEdit) ? old('direccion', $AlbergueEdit->direccion) : old('direccion')); ?>"
                                                class="inputField" name="direccion">
                                            <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small style="color:red"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>


                                        <div class="inputContainer">
                                            <label class="inputFieldLabel" for="dui">Miembro responsable</label>
                                            <i class="inputFieldIcon fas fa-user"></i>
                                            <select id="miembro" name="miembro" class="inputField">
                                                <option value=""
                                                    <?php echo e(old('miembro') == '' && !isset($AlbergueEdit) ? 'selected' : ''); ?>>
                                                    Seleccione...
                                                </option>
                                                <?php use App\Models\Miembro; ?>
                                                <?php $__currentLoopData = Miembro::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miembro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($miembro->estado == 1): ?>
                                                        <option value="<?php echo e($miembro->idMiembro); ?>"
                                                            <?php echo e(isset($AlbergueEdit) ? ($AlbergueEdit->miembro->idMiembro == $miembro->idMiembro ? 'selected' : '') : (old('nombre') == $miembro->idMiembro ? 'selected' : '')); ?>>
                                                            <?php echo e($miembro->nombres); ?> <?php echo e($miembro->apellidos); ?>

                                                        </option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['miembro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small style="color:red"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                    <div style="display: flex; align-items: flex-end; gap: 10px; justify-content: center">
                                        <button type="submit" class="button button-pri">
                                            <i class="svg-icon fa-regular fa-floppy-disk"></i>
                                            <span class="lable">
                                                <?php if(isset($AlbergueEdit)): ?>
                                                    Modificar
                                                <?php else: ?>
                                                    Guardar
                                                <?php endif; ?>
                                            </span>
                                        </button>
                                        <button onclick="<?php echo e(url('albergue')); ?>" type="button" id="btnCancelar"
                                            class="button button-red">
                                            <i class="svg-icon fas fa-rotate-right"></i>
                                            <span class="lable">Cancelar</span>
                                        </button>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </main>
        <div class="floating-button" data-toggle="modal" data-target="#ayudaAlbergue" data-bs-pp="tooltip" data-bs-placement="top" title="Ayuda">
            <span>?</span>
        </div>   
    </div>
   
    <?php echo $__env->make('albergue.modalesAlbergue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animal_care\resources\views/albergue/index.blade.php ENDPATH**/ ?>